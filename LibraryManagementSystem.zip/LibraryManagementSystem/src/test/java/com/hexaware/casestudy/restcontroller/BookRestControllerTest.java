package com.hexaware.casestudy.restcontroller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BookRestControllerTest {

	@Test
	void testBookRestController() {
		fail("Not yet implemented");
	}

	@Test
	void testAddBook() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdateBook() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteById() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBookByTitle() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBookByAuthor() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBookBySubject() {
		fail("Not yet implemented");
	}

}
